const tabs = document.querySelectorAll('.menu-tabs li');

tabs.forEach(tab => {
  tab.addEventListener('click', function() {
    // Remove active class from all tabs
    tabs.forEach(t => t.classList.remove('active'));
    
    // Add active class to clicked tab
    this.classList.add('active');
  });
});
