<?php

// Debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// FIXME: Error 500 when using include, require, or require_once.
// Require our main menu
// require_once '/MainMenu.inc.php';

require_once __DIR__ . '/../MainMenu.inc.php';

// Show all information, defaults to INFO_ALL
// phpinfo();

// Show just the configuration information.
// phpinfo(8) yields identical results.
phpinfo(INFO_CONFIGURATION);

?>

