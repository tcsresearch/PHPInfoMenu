<?php
// Other PHP code and HTML might be here

// Include the menu file
include('MainMenu.inc.php'); 

// The rest of your page content goes here
?>

