<?php
phpinfo( );
?>