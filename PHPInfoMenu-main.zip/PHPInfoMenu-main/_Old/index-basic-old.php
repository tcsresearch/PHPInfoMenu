<?php
phpinfo( );
?>