<?php

// Include our main menu
include_once 'MainMenu.inc.php'; 

// Show all information, defaults to INFO_ALL
// phpinfo();

// Show just the environment information.
// phpinfo(8) yields identical results.
phpinfo(INFO_ENVIRONMENT);

?>

